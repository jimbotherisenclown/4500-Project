﻿
namespace Photon.Voice.Unity
{
    public class PhotonVoiceCreatedParams
    {
        public Voice.LocalVoice Voice { get; set; }
        public Voice.IAudioDesc AudioDesc { get; set; }
    }
}
