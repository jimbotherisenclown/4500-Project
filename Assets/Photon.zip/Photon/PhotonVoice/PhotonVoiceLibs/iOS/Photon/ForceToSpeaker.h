
#import <Foundation/Foundation.h>


void Photon_IOSAudio_ForceToSpeaker();
bool Photon_IOSAudio_HeadsetConnected();
